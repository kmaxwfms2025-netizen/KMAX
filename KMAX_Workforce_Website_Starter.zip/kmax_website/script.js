const WA_NUMBER = '916364777638';
const menu = document.getElementById('menu');
const nav = document.getElementById('nav');
menu.addEventListener('click', () => { const open = nav.classList.toggle('open'); menu.setAttribute('aria-expanded', String(open)); });
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('search').addEventListener('input', e => {
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll('#jobGrid article').forEach(card => {
    card.hidden = !((card.dataset.key + ' ' + card.innerText).toLowerCase().includes(q));
  });
});
document.querySelectorAll('.apply').forEach(btn => btn.addEventListener('click', () => {
  const role = btn.dataset.role;
  const text = `Hello KMAX, I would like to enquire/apply for the ${role} role. Please share current vacancy details, eligibility, salary range, work location and application process.`;
  window.open(`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
}));
document.getElementById('employerForm').addEventListener('submit', e => {
  e.preventDefault();
  const f = new FormData(e.currentTarget);
  const message = [
    'Hello KMAX, I would like to enquire about staffing services.',
    `Company: ${f.get('company')}`,
    `Contact person: ${f.get('person')}`,
    `Phone: ${f.get('phone')}`,
    `Requirement: ${f.get('service')}`,
    `Details: ${f.get('details') || 'Not provided'}`
  ].join('\n');
  window.open(`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`, '_blank', 'noopener');
});
